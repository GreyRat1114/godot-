extends Camera2D

var playerPosition=Vector2.ZERO
var strength=0.0
var recovery_speed=16.0
func _read():
	global_position.x=-40
	global_position.y=-80

func match_player_position():
	var players=get_tree().get_nodes_in_group("player")
	if players.size()>0:
		var player=players[0]
		playerPosition=player.global_position
func _process(delta):
	offset=Vector2(rand_range(-strength,strength),rand_range(-strength,strength))
	strength=move_toward(strength,0,recovery_speed*delta)
	
	match_player_position()
	if playerPosition.x>-352 and playerPosition.x<-160:
		global_position.x=lerp(playerPosition.x,global_position.x,pow(2,-5*delta))
	if playerPosition.x<-352 :
		global_position.x=lerp(-528,global_position.x,pow(2,-7*delta))
	if playerPosition.x>-160:
		global_position.x=lerp(-160,global_position.x,pow(2,-7*delta))

func camera_shake_2():
	strength=2
	
func camera_shake_3():
	strength=3
	
func camera_shake_4():
	strength=4	
	
func camera_shake_5():
	strength=5	
	
func start_timer(time_scale):
	var timer=Timer.new()
	timer.wait_time=0.01
	timer.one_shot=true
	timer.connect("timeout",self,"_on_timer_timeout")
	add_child(timer)
	timer.start()
	Engine.time_scale=time_scale

func _on_timer_timeout():
	Engine.time_scale=1
	
func enemy_hurt():
	strength=4
	start_timer(0.1)
	
func enemy_die():
	strength=15
	start_timer(0.7)
	
func player_hurt():
	strength=3
	start_timer(0.7)
	
func player_die():
	strength=15
	start_timer(0.7)

func pindao():
	strength=1
	start_timer(0.05)
	
func zhanhou():
	strength=2
