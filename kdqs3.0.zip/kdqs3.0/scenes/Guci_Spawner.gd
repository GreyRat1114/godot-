extends Node2D

func spawn_guci():
	var boss=get_node("/root/MainScene/Enemy/Boss")
	var guci_scene=load("res://scenes/Guci.tscn")
	for i in range(10):
		var guci_node_right=guci_scene.instance()
		guci_node_right.position.x=boss.position.x+40+40*i
		guci_node_right.position.y=16;
		if guci_node_right.position.x>-672 and guci_node_right.position.x<-408:
			add_child(guci_node_right)
		var guci_node_left=guci_scene.instance()	
		guci_node_left.position.x=boss.position.x-40-40*i
		guci_node_left.position.y=16;
		if guci_node_left.position.x>-672 and guci_node_left.position.x<-408:
			add_child(guci_node_left)
		yield(get_tree().create_timer(0.2),"timeout")
	pass
