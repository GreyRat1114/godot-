extends KinematicBody2D
var velocity=Vector2.ZERO
enum State{NORMAL,DASH,ATTACK,ATTACK_UP,ATTACK_DOWN,ATTACK_JUMP,HURT,DIE_1,DIE_2,HEAL,HEIBO,SCARED}
var currentState=State.NORMAL
var isStateNew =true
var gravity=580
var dsudu=2000
var maxsudu=110
var jumpSpeed=280
var jumpHigher=4
var maxDashSpeed=600
var canDash=true
var canDoubleJump=true
var jumpSpeed2=250
var attack_index=0
var hurt_direction :String
export var isDoubleJump=false
func _ready():
	pass
func _process(delta):
	match currentState:
		State.NORMAL:
			process_normal(delta)
		State.DASH:
			process_dash(delta)
		State.ATTACK:
			process_attack(delta)
		State.ATTACK_UP:
			process_attack_up(delta)
		State.ATTACK_DOWN:
			process_attack_down(delta)
		State.ATTACK_JUMP:
			process_attack_jump(delta)
		State.HURT:
			process_hurt(delta)
		State.DIE_1:
			process_die_1(delta)
		State.DIE_2:
			process_die_2(delta)
		State.HEAL:
			process_heal(delta)
		State.HEIBO:
			process_heibo(delta)
		State.SCARED:
			process_scared(delta)
	isStateNew=false
	
func change_state(newState):
	currentState=newState
	isStateNew=true
	
func get_movement_vector():#监听盘输入，返回移动状态
	var moveVector=Vector2.ZERO
	moveVector.x=Input.get_action_strength("move_right")-Input.get_action_strength("move_left")
	moveVector.y=-1 if Input.is_action_just_pressed("jump") else 0
	return moveVector

func update_animation():#跳跃移动待机动画切换
	var moveVector=get_movement_vector()
	
	if !is_on_floor():
		if isDoubleJump==true:
			$AnimationPlayer.play("二段跳")
		else:
			if velocity.y<0:
				$AnimationPlayer.play("跳跃")
			if velocity.y>0:
				$AnimationPlayer.play("下落")				
	elif moveVector.x!=0:
		if Input.is_action_pressed("heal") and $"/root/PlayerSoul".PlayerSoul>=3:
			call_deferred("change_state",State.HEAL)
		$AnimationPlayer.play("移动")
	else:
		if Input.is_action_pressed("heal") and $"/root/PlayerSoul".PlayerSoul>=3:
			call_deferred("change_state",State.HEAL)		
		$AnimationPlayer.play("待机")	
	
func turn_direction():#左右移动转向
	var moveVector=get_movement_vector()
	if moveVector.x!=0:
		$SpriteArea.scale.x=1 if moveVector.x >0 else -1
		$HurtboxArea.scale.x=1 if moveVector.x >0 else -1
		$Attack_1.scale.x=1 if moveVector.x >0 else -1
		$Attack_2.scale.x=1 if moveVector.x >0 else -1
		$Attack_Up.scale.x=1 if moveVector.x >0 else -1
		$Attack_Down.scale.x=1 if moveVector.x >0 else -1	
		$CollisionPolygon2D.scale.x=1 if moveVector.x >0 else -1	


func apply_gravity_movement(delta):
	var moveVector=get_movement_vector()
	velocity.x+=moveVector.x*dsudu*delta
	velocity.x=clamp(velocity.x,-maxsudu,maxsudu)
	if(moveVector.x==0):
		velocity.x=lerp(0.0,1.0*velocity.x,pow(2,-50*delta))	
	velocity.y+=gravity*delta
	velocity=move_and_slide(velocity,Vector2.UP)
	
func player_change_state_to_scard():
	call_deferred("change_state",State.SCARED)
	
func process_scared(delta):
	if isStateNew:
		var boss=get_node("/root/MainScene/Enemy/Boss")		
		$AnimationPlayer.play("抬头")
		$SpriteArea.scale.x=1 if boss.position.x > position.x else -1
		$HurtboxArea.scale.x=1 if boss.position.x >position.x else -1
		$Attack_1.scale.x=1 if boss.position.x >position.x else -1
		$Attack_2.scale.x=1 if boss.position.x >position.x else -1
		$Attack_Up.scale.x=1 if boss.position.x >position.x else -1
		$Attack_Down.scale.x=1 if boss.position.x >position.x else -1	
		$CollisionPolygon2D.scale.x=1 if boss.position.x >position.x else -1			
		velocity.x=-200 if boss.position.x >position.x else 200
	velocity.x=lerp(0,velocity.x,pow(2,-10*delta))
	velocity.y+=gravity*delta
	velocity=move_and_slide(velocity,Vector2.UP)		
	if !$AnimationPlayer.is_playing():
		call_deferred("change_state",State.NORMAL)
		
			
func process_normal(delta: float):
	#print(velocity.y)
	var moveVector=get_movement_vector()
		
	if moveVector.y ==-1:
		if is_on_floor():
			velocity.y=jumpSpeed*moveVector.y
		elif canDoubleJump==true:
			velocity.y=jumpSpeed2*moveVector.y
			isDoubleJump=true
			canDoubleJump=false
			
	if velocity.y<0 and !Input.is_action_pressed("jump"):
		velocity.y+=jumpHigher*delta*gravity		
	
	turn_direction()
	update_animation()
	apply_gravity_movement(delta)
	#apply_gravity_movement(delta)
	if is_on_floor():
		canDash=true
		canDoubleJump=true;
		
	if Input.is_action_just_pressed("dash") and canDash ==true:
		call_deferred("change_state",State.DASH)
	if Input.is_action_just_pressed("attack") and $AttackTimer.is_stopped():
		call_deferred("change_state",State.ATTACK)
	if Input.is_action_just_pressed("attack") and Input.get_action_strength("move_up") and $AttackTimer.is_stopped():
		call_deferred("change_state",State.ATTACK_UP)
	if Input.is_action_just_pressed("attack") and Input.get_action_strength("move_down") and is_on_floor()==false and $AttackTimer.is_stopped():
		call_deferred("change_state",State.ATTACK_DOWN)
	if Input.is_action_just_pressed("fashu")and $"/root/PlayerSoul".PlayerSoul>=3:
		call_deferred("change_state",State.HEIBO)
	pass

func process_dash(delta: float):
	turn_direction()
	if isStateNew:
		var hasBlackDash=$BlackDash.hasBlackDash
		var moveVector=get_movement_vector()
		var velocityMod=1
		if moveVector.x!=0:
			velocityMod =sign(moveVector.x)
		else:
			velocityMod= 1 if $SpriteArea.scale.x==1 else -1
		velocity.x=velocityMod*maxDashSpeed
		velocity.y=0
		if hasBlackDash == true:
			$HurtboxArea/Hurtbox.disabled=true
			$BlackDash.spawn_blackdash()
			$AnimationPlayer.play("黑冲")
		else:
			$AnimationPlayer.play("冲刺")
		canDash=false
	velocity.x=lerp(0.0,1.0*velocity.x,pow(2,-13*delta))	
	velocity=move_and_slide(velocity,Vector2.UP)
	if !$AnimationPlayer.is_playing():
		if $WudiTimer.is_stopped():
			$HurtboxArea/Hurtbox.disabled=false
		call_deferred("change_state",State.NORMAL)

func process_attack(delta):
	if isStateNew:
		if attack_index==0:
			$AnimationPlayer.play("横劈1")
			attack_index=1
		else:
			$AnimationPlayer.play("横劈2")
			attack_index=0			
	if !$AnimationPlayer.is_playing():
		$AttackTimer.start()
		call_deferred("change_state",State.NORMAL)
	apply_gravity_movement(delta)
	if Input.is_action_just_pressed("dash") and canDash ==true:
		call_deferred("change_state",State.DASH)	
func process_attack_up(delta):
	if isStateNew:
		$AnimationPlayer.play("上劈")
	if !$AnimationPlayer.is_playing():
		call_deferred("change_state",State.NORMAL)
		$AttackTimer.start()
	apply_gravity_movement(delta)
	if Input.is_action_just_pressed("dash") and canDash ==true:
		call_deferred("change_state",State.DASH)	
func process_attack_down(delta):
	if isStateNew:
		$AnimationPlayer.play("下劈")
	if !$AnimationPlayer.is_playing():
		call_deferred("change_state",State.NORMAL)
		$AttackTimer.start()
	apply_gravity_movement(delta)
	if Input.is_action_just_pressed("dash") and canDash ==true:
		call_deferred("change_state",State.DASH)	
		
func wudi():
	$HurtboxArea/Hurtbox.disabled=true
	$WudiTimer.start()
	while true:
		$SpriteArea/Sprite.visible=false
		yield(get_tree().create_timer(0.06),"timeout")	
		$SpriteArea/Sprite.visible=true
		yield(get_tree().create_timer(0.06),"timeout")	
		if $WudiTimer.is_stopped() and $PindaoWudiTimer2.is_stopped():
			$HurtboxArea/Hurtbox.disabled=false
			break	
			
func process_heibo(delta):
	if isStateNew:
		$"/root/PlayerSoul".PlayerSoul-=3
		$"/root/PlayerSoul".refresh_player_soul()
		turn_direction()
		velocity=Vector2.ZERO;
		$AnimationPlayer.play("黑波")
	if !$AnimationPlayer.is_playing():
		call_deferred("change_state",State.NORMAL)
		
func spawn_heibo():
	$"/root/MainScene/GameCamera".camera_shake_4()
	
	var heibo_spawner=get_node("/root/MainScene/Player/FashuSpawner")
	print($SpriteArea.scale.x)
	if $SpriteArea.scale.x==-1:
		position.x+=5
		heibo_spawner.spawn_heibo_left()
	else:
		position.x-=5
		heibo_spawner.spawn_heibo_right()			
		
		
func process_hurt(delta):
	if isStateNew:
		
		wudi()
		velocity.x=-50 if hurt_direction =="left" else 50
		velocity.y=-50
		$SpriteArea.scale.x=1 if hurt_direction =="left" else -1
		$HurtboxArea.scale.x=1 if hurt_direction =="left" else -1
		$Attack_1.scale.x=1 if hurt_direction =="left" else -1
		$Attack_2.scale.x=1 if hurt_direction =="left" else -1
		$Attack_Up.scale.x=1 if hurt_direction =="left" else -1
		$Attack_Down.scale.x=1 if hurt_direction =="left" else -1	
		$CollisionPolygon2D.scale.x=1 if hurt_direction =="left" else -1	
		$"/root/MainScene/GameCamera".player_hurt()
		$AnimationPlayer.play("受击")
	velocity.y+=gravity*delta
	velocity=move_and_slide(velocity,Vector2.UP)
	if !$AnimationPlayer.is_playing():
		call_deferred("change_state",State.NORMAL)

func process_die_1(delta):
	if isStateNew:
		$"/root/MainScene/GameCamera".player_die()
		$HurtboxArea/Hurtbox.disabled=true
		$AnimationPlayer.play("死亡1")
	if !$AnimationPlayer.is_playing():
		call_deferred("change_state",State.DIE_2)

func process_die_2(delta):
	if isStateNew:
		$AnimationPlayer.play("死亡2")

func process_heal(delta):
	if isStateNew:
		$AnimationPlayer.play("回血")
	if !$AnimationPlayer.is_playing():
		
		call_deferred("change_state",State.NORMAL)
func heal():
	$"/root/MainScene/GameCamera".camera_shake_2()
	$"/root/PlayerSoul".PlayerSoul-=3
	$"/root/PlayerSoul".refresh_player_soul()
	$"/root/PlayerHeathBar".PlayerHeath+=5
	$"/root/PlayerHeathBar".refresh_player_health()
			
func _on_HurtboxArea_area_entered(area):
	$"/root/PlayerHeathBar".PlayerHeath-=5
	$"/root/PlayerHeathBar".refresh_player_health()
	if area.global_position.x>global_position.x:
		hurt_direction="left"
	else:
		hurt_direction="right"
	if $"/root/PlayerHeathBar".PlayerHeath<=0:
		call_deferred("change_state",State.DIE_1)
	else:	
		call_deferred("change_state",State.HURT)

func process_attack_jump(delta):
	if isStateNew:
		canDash=true
		canDoubleJump=true
		velocity.x=0
		velocity.y=-260
		$AnimationPlayer.play("下劈")
	if velocity.y>=-130:
		call_deferred("change_state",State.NORMAL)
	apply_gravity_movement(delta)
	if Input.is_action_just_pressed("dash") and canDash ==true:
		call_deferred("change_state",State.DASH)	
	
func _on_Attack_1_area_entered(area):
	if area.name=="daoguangboxArea":
		var pos1=global_position
		var pos2=area.global_position
		var effect_pos=(pos1+pos2)/2
		$"/root/MainScene/TexiaoSpawner".spawn_pindao_texiao(effect_pos)
		$"/root/MainScene/GameCamera".pindao()
		call_deferred("pindao_wudi")
	else:	
		$"/root/PlayerSoul".PlayerSoul+=1
		$"/root/PlayerSoul".refresh_player_soul()
		if $SpriteArea.scale.x==1:
			global_position.x-=5
		else:
			global_position.x+=5


func _on_Attack_2_area_entered(area):
	if area.name=="daoguangboxArea":
		var pos1=global_position
		var pos2=area.global_position
		var effect_pos=(pos1+pos2)/2
		$"/root/MainScene/TexiaoSpawner".spawn_pindao_texiao(effect_pos)
		$"/root/MainScene/GameCamera".pindao()
		call_deferred("pindao_wudi")
	else:	
		$"/root/PlayerSoul".PlayerSoul+=1
		$"/root/PlayerSoul".refresh_player_soul()
		if $SpriteArea.scale.x==1:
			global_position.x-=5
		else:
			global_position.x+=5


func _on_Attack_Up_area_entered(area):
	if area.name=="daoguangboxArea":
		var pos1=global_position
		var pos2=area.global_position
		var effect_pos=(pos1+pos2)/2
		$"/root/MainScene/TexiaoSpawner".spawn_pindao_texiao(effect_pos)
		$"/root/MainScene/GameCamera".pindao()
		call_deferred("pindao_wudi")
	else:	
		$"/root/PlayerSoul".PlayerSoul+=1
		$"/root/PlayerSoul".refresh_player_soul()	


func _on_Attack_Down_area_entered(area):
	if area.name=="daoguangboxArea":
		var pos1=global_position
		var pos2=area.global_position
		var effect_pos=(pos1+pos2)/2
		$"/root/MainScene/TexiaoSpawner".spawn_pindao_texiao(effect_pos)
		$"/root/MainScene/GameCamera".pindao()
		call_deferred("pindao_wudi")
	else:	
		$"/root/PlayerSoul".PlayerSoul+=1
		$"/root/PlayerSoul".refresh_player_soul()	
	call_deferred("change_state",State.ATTACK_JUMP)
func pindao_wudi():
	$HurtboxArea/Hurtbox.disabled=true
	$PindaoWudiTimer2.start()
	

func _on_PindaoWudiTimer2_timeout():
	if $WudiTimer.is_stopped() and $PindaoWudiTimer2.is_stopped():		
		$HurtboxArea/Hurtbox.disabled=false
