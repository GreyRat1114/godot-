extends Node2D

func spawn_pindao_texiao(effect_pos):
	var pindao_scene=load("res://scenes/PindaoTexiao.tscn")
	var pindao_node=pindao_scene.instance()
	pindao_node.position=effect_pos
	add_child(pindao_node)

func spawn_zhanhou_texiao(boss_pos):
	var zhanhou_scene=load("res://scenes/ZhanhouTexioa.tscn")
	var zhanhou_node=zhanhou_scene.instance()
	zhanhou_node.position=boss_pos
	add_child(zhanhou_node)

func delete_zhanhou():
	var zhanhou_node=get_node("/root/MainScene/TexiaoSpawner/ZhanhouTexioa")
	zhanhou_node.queue_free()

func spawn_hit_particle(boss_pos):
	var particle=load("res://scenes/HitParticle.tscn")
	var particle_node=particle.instance()
	particle_node.position=boss_pos
	add_child(particle_node)
