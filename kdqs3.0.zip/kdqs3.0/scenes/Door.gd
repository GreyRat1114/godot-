extends KinematicBody2D
func _ready():
	$AnimationPlayer.play("default")
	
func open():
	$AnimationPlayer.play("open")

func close():
	$AnimationPlayer.play("close")
