extends KinematicBody2D
var direction=1
var velocity=Vector2.ZERO
func _ready():
	$AnimationPlayer.play("idle")
	
func _process(delta):
	if direction==1:
		velocity.x=-400
	else:
		velocity.x=400
	velocity=move_and_slide(velocity,Vector2.UP)
	
