extends Particles2D

func _ready():
	emitting=true
	var total_time=lifetime+0.1
	yield(get_tree().create_timer(total_time),"timeout")
	queue_free()
