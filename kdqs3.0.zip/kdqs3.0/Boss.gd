extends KinematicBody2D
enum State{IDLE,HUIKAN,HUIKAN_ZHUNBEI,SHANGTIAO,SHANGTIAO_ZHUNBEI,READY,MOVE,JUMP,FALL,JUMP2,XIACHUO_ZHUNBEI,XIACHUO,XIACHUO_JIESHU,BACK_JUMP,BACK_FALL,HURT,DIE_1,DIE_2,BAIBO,READY_2,ZHANHOU_ZHUNBEI,ZHANHOU}
var currentState=State.READY
var isStateNew =true
var velocity=Vector2.ZERO
var gravity=1000
var playerPosition=Vector2.ZERO
var BossHealth=1000


func _ready():
	global_position.x=-600
	global_position.y=-248
	$HurtboxArea/Hurtbox.disabled=false
	$HitboxArea/Hitbox.disabled=false
	$daoguangboxArea/daoguangbox.disabled=false
	
	$AnimationPlayer.play("待机")
	
func _process(delta):
	match_player_position()
	match currentState:
		State.READY:
			process_ready(delta)
		State.IDLE:
			process_idle(delta)
		State.HUIKAN:
			process_huikan(delta)
		State.HUIKAN_ZHUNBEI:
			process_huikan_zhunbei(delta)
		State.SHANGTIAO:
			process_shangtiao(delta)
		State.SHANGTIAO_ZHUNBEI:
			process_shangtiao_zhunbei(delta)
		State.MOVE:
			process_move(delta)
		State.JUMP:
			process_jump(delta)
		State.FALL:
			process_fall(delta)	
		State.JUMP2:
			process_jump2(delta)		
		State.XIACHUO:
			process_xiachuo(delta)
		State.XIACHUO_ZHUNBEI:
			process_xiachuo_zhunbei(delta)
		State.XIACHUO_JIESHU:
			process_xiachuo_jieshu(delta)
		State.BACK_JUMP:
			process_back_jump(delta)
		State.BACK_FALL:
			process_back_fall(delta)
		State.HURT:
			process_hurt(delta)
		State.DIE_1:
			process_die_1(delta)
		State.DIE_2:
			process_die_2(delta)		
		State.BAIBO:
			process_baibo(delta)
		State.READY_2:
			process_ready_2(delta)
		State.ZHANHOU_ZHUNBEI:
			process_zhanhou_zhunbei(delta)
		State.ZHANHOU:
			process_zhanhou(delta)			
						
	isStateNew=false
	
func change_state(newState):
	currentState=newState
	isStateNew=true

func turn_direction():


	$SpriteArea.scale.x=1 if playerPosition.x<global_position.x else -1
	$HurtboxArea.scale.x=1 if playerPosition.x<global_position.x else -1

	$HitboxArea.scale.x=1 if playerPosition.x<global_position.x else -1
	$daoguangboxArea.scale.x=1 if playerPosition.x<global_position.x else -1
	$CollisionPolygon2D.scale.x=1 if playerPosition.x<global_position.x else -1
func match_player_position():
	var players=get_tree().get_nodes_in_group("player")
	if players.size()>0:
		var player=players[0]
		playerPosition=player.global_position	
func process_ready(delta):
	if isStateNew:
		turn_direction()

	$AnimationPlayer.play("待机")
	if playerPosition.x<-420:
		var door =get_node("/root/MainScene/doors/Door")
		door.close()
		call_deferred("change_state",State.READY_2)
func process_ready_2(delta):
	if isStateNew:
		turn_direction()
		$AnimationPlayer.play("下落")
	velocity.y+=gravity*delta
	velocity=move_and_slide(velocity,Vector2.UP)
	if is_on_floor():
		velocity=Vector2.ZERO
		call_deferred("change_state",State.ZHANHOU_ZHUNBEI)
func process_zhanhou_zhunbei(delta):
	if isStateNew:
		$AnimationPlayer.play("战吼准备")
	if !$AnimationPlayer.is_playing():
		call_deferred("change_state",State.ZHANHOU)			
		
		
func process_zhanhou(delta):
	$"/root/MainScene/GameCamera".zhanhou()
	if isStateNew:
		var boss_pos=position
		boss_pos.y-=12
		$"/root/MainScene/TexiaoSpawner".spawn_zhanhou_texiao(boss_pos)
		var player=get_node("/root/MainScene/Player/Player")
		player.player_change_state_to_scard()
		$AnimationPlayer.play("战吼")	
	if !$AnimationPlayer.is_playing():
		call_deferred("change_state",State.IDLE)	
		$"/root/MainScene/TexiaoSpawner".delete_zhanhou()
				
func process_idle(delta):
	turn_direction()
	if isStateNew:
		velocity=Vector2.ZERO
		$AnimationPlayer.play("待机")
	velocity.y+=gravity*delta
	velocity=move_and_slide(velocity,Vector2.UP)
	if !$AnimationPlayer.is_playing():
		if randf()<0.4:
			if abs(playerPosition.x-global_position.x)<80:
				call_deferred("change_state",State.HUIKAN_ZHUNBEI)
			else:
				if randf()>0.5:
					call_deferred("change_state",State.MOVE)
				else:
					call_deferred("change_state",State.JUMP)
		else:
			if randf()>0.5:
				call_deferred("change_state",State.BACK_JUMP)
			else:				
				call_deferred("change_state",State.JUMP2)
func process_huikan(delta):
	if isStateNew:
		velocity.x= -300 if $SpriteArea.scale.x==1 else 300
		velocity.y=0
		$AnimationPlayer.play("挥砍")
	velocity.y+=gravity*delta
	velocity=move_and_slide(velocity,Vector2.UP)
	if !$AnimationPlayer.is_playing():
		call_deferred("change_state",State.SHANGTIAO_ZHUNBEI)
func process_huikan_zhunbei(delta):
	if isStateNew:
		velocity=Vector2.ZERO
		$AnimationPlayer.play("挥砍准备")
	if !$AnimationPlayer.is_playing():
		call_deferred("change_state",State.HUIKAN)
func process_shangtiao(delta):
	if isStateNew:
		velocity.x=-80 if $SpriteArea.scale.x==1 else 80
		velocity.y=-400
		$AnimationPlayer.play("上挑")
	velocity.y+=gravity*delta
	velocity=move_and_slide(velocity,Vector2.UP)
	if !$AnimationPlayer.is_playing():
		call_deferred("change_state",State.FALL)	
		
func process_shangtiao_zhunbei(delta):
	if isStateNew:
		$AnimationPlayer.play("上挑准备")
	if !$AnimationPlayer.is_playing():
		call_deferred("change_state",State.SHANGTIAO)
		
func process_move(delta):
	turn_direction()
	if isStateNew:
		if playerPosition.x>global_position.x:
			velocity.x=80
		else:
			velocity.x=-80
		velocity.y=0
		$AnimationPlayer.play("移动")
	velocity.y+=gravity*delta
	velocity=move_and_slide(velocity,Vector2.UP)
	if abs(playerPosition.x-global_position.x)<80:
		call_deferred("change_state",State.HUIKAN_ZHUNBEI)
func process_jump(delta):
	if isStateNew:
		velocity.x=playerPosition.x-global_position.x
		velocity.y=-400		
		$AnimationPlayer.play("跳跃")
	velocity.y+=gravity*delta
	velocity=move_and_slide(velocity,Vector2.UP)
	if velocity.y>0:
		call_deferred("change_state",State.FALL)
func process_fall(delta):
	if isStateNew:
		$AnimationPlayer.play("下落")
	velocity.y+=gravity*delta
	velocity=move_and_slide(velocity,Vector2.UP)
	if is_on_floor():
		call_deferred("change_state",State.IDLE)
		
func process_jump2(delta):
	if isStateNew:
		velocity.x=(playerPosition.x-global_position.x)*2
		velocity.y=-400		
		$AnimationPlayer.play("跳跃")
	velocity.y+=gravity*delta
	velocity=move_and_slide(velocity,Vector2.UP)
	if velocity.y>0:
		call_deferred("change_state",State.XIACHUO_ZHUNBEI)		
		
func process_xiachuo_zhunbei(delta):
	if isStateNew:
		velocity=Vector2.ZERO;
		$AnimationPlayer.play("下戳准备")
	if !$AnimationPlayer.is_playing():
		call_deferred("change_state",State.XIACHUO)		
		
func process_xiachuo(delta):
	$"/root/MainScene/GameCamera".camera_shake_2()
	if isStateNew:
		$AnimationPlayer.play("下戳")
	velocity.y+=100
	velocity=move_and_slide(velocity,Vector2.UP)
	if is_on_floor():
		call_deferred("change_state",State.XIACHUO_JIESHU)				
		
func process_xiachuo_jieshu(delta):
	if isStateNew:
		velocity=Vector2.ZERO;
		$AnimationPlayer.play("下戳结束")

	if !$AnimationPlayer.is_playing():
		var guci_spawner=get_node("/root/MainScene/Enemy/Guci_Spawner")
		guci_spawner.spawn_guci()
		call_deferred("change_state",State.IDLE)			
		
func process_back_jump(delta):
	if isStateNew:
		velocity.x=-672-global_position.x if playerPosition.x>-540 else -284-global_position.x
		velocity.y=-400		
		if velocity.x<0 and $SpriteArea.scale.x==1:
			$AnimationPlayer.play("跳跃")
		if velocity.x<0 and $SpriteArea.scale.x==-1:
			$AnimationPlayer.play("后跳")		
		if velocity.x>0 and $SpriteArea.scale.x==1:
			$AnimationPlayer.play("后跳")
		if velocity.x<0 and $SpriteArea.scale.x==-11:
			$AnimationPlayer.play("跳跃")		
	velocity.y+=gravity*delta
	velocity=move_and_slide(velocity,Vector2.UP)
	if velocity.y>0:
		call_deferred("change_state",State.BACK_FALL)
		
func process_back_fall(delta):
	if isStateNew:
		if velocity.x<0 and $SpriteArea.scale.x==1:
			$AnimationPlayer.play("跳跃")
		if velocity.x<0 and $SpriteArea.scale.x==-1:
			$AnimationPlayer.play("后跳下落")		
		if velocity.x>0 and $SpriteArea.scale.x==1:
			$AnimationPlayer.play("后跳下落")
		if velocity.x<0 and $SpriteArea.scale.x==-11:
			$AnimationPlayer.play("跳跃")	
	velocity.y+=gravity*delta
	velocity=move_and_slide(velocity,Vector2.UP)
	if is_on_floor():
		call_deferred("change_state",State.BAIBO)
	
func process_baibo(delta):
	if isStateNew:
		turn_direction()
		velocity=Vector2.ZERO;
		$AnimationPlayer.play("白波")
	if !$AnimationPlayer.is_playing():
		call_deferred("change_state",State.IDLE)	
func spawn_baibo():
	$"/root/MainScene/GameCamera".camera_shake_5()
	var baibo_spawner=get_node("/root/MainScene/Enemy/BaiboSpawner")
	if $SpriteArea.scale.x==1:
		baibo_spawner.spawn_baibo_left()
	else:
		baibo_spawner.spawn_baibo_right()		
						
func process_hurt(delta):
	if isStateNew:
		$"/root/MainScene/GameCamera".enemy_hurt()
		turn_direction()
		$AnimationPlayer.play("僵直")
		velocity.x=+400 if $SpriteArea.scale.x==1 else -400		
	velocity.x=lerp(0,velocity.x,pow(2,-10*delta))			
	velocity.y+=gravity*delta
	velocity=move_and_slide(velocity,Vector2.UP)				
	if !$AnimationPlayer.is_playing():			
		call_deferred("change_state",State.IDLE)
		
func process_die_1(delta):
	if isStateNew:
		$"/root/MainScene/GameCamera".enemy_hurt()
		$HurtboxArea/Hurtbox.disabled=true
		$HitboxArea/Hitbox.disabled=true
		$daoguangboxArea/daoguangbox.disabled=true
		turn_direction()
		$AnimationPlayer.play("僵直")
		velocity.x=+400 if $SpriteArea.scale.x==1 else -400		
	velocity.x=lerp(0,velocity.x,pow(2,-10*delta))			
	velocity.y+=gravity*delta
	velocity=move_and_slide(velocity,Vector2.UP)				
	if !$AnimationPlayer.is_playing():			
		call_deferred("change_state",State.DIE_2)
		
func process_die_2(delta):
	if isStateNew:
		$AnimationPlayer.play("死亡")
	
func enemy_die_camera_shake():
	$"/root/MainScene/GameCamera".enemy_die()	

func door_open():
	var door =get_node("/root/MainScene/doors/Door")
	door.open()
	
func _on_HurtboxArea_area_entered(area):
	$MateriaTimer.start()
	$SpriteArea/Sprite.use_parent_material=false
	$"/root/MainScene/TexiaoSpawner".spawn_hit_particle(position)
	if BossHealth<=1000 and BossHealth>=750:
		if area.name=="Attack_1":
			BossHealth-=15
		if area.name=="Attack_2":
			BossHealth-=15
		if area.name=="Attack_Up":
			BossHealth-=15
		if area.name=="Attack_Down":
			BossHealth-=15		
		if area.name=="HeiboHitboxArea":
			BossHealth-=60		
		if BossHealth<750:
			call_deferred("change_state",State.HURT)	
		if BossHealth<=0:
			call_deferred("change_state",State.DIE_1)
	if BossHealth<=750 and BossHealth>=500:
		if area.name=="Attack_1":
			BossHealth-=15
		if area.name=="Attack_2":
			BossHealth-=15
		if area.name=="Attack_Up":
			BossHealth-=15
		if area.name=="Attack_Down":
			BossHealth-=15		
		if area.name=="HeiboHitboxArea":
			BossHealth-=60	
		if BossHealth<500:
			call_deferred("change_state",State.HURT)	
		if BossHealth<=0:
			call_deferred("change_state",State.DIE_1)
	if BossHealth<=500 and BossHealth>=250:
		if area.name=="Attack_1":
			BossHealth-=15
		if area.name=="Attack_2":
			BossHealth-=15
		if area.name=="Attack_Up":
			BossHealth-=15
		if area.name=="Attack_Down":
			BossHealth-=15		
		if area.name=="HeiboHitboxArea":
			BossHealth-=60				
		if BossHealth<250:
			call_deferred("change_state",State.HURT)	
		if BossHealth<=0:
			call_deferred("change_state",State.DIE_1)		
	if BossHealth<=250 and BossHealth>=0:
		if area.name=="Attack_1":
			BossHealth-=15
		if area.name=="Attack_2":
			BossHealth-=15
		if area.name=="Attack_Up":
			BossHealth-=15
		if area.name=="Attack_Down":
			BossHealth-=15		
		if area.name=="HeiboHitboxArea":
			BossHealth-=60				
		if BossHealth<=0:
			call_deferred("change_state",State.DIE_1)				
	print(BossHealth)			
	pass # Replace with function body.



func _on_MateriaTimer_timeout():
	$SpriteArea/Sprite.use_parent_material=true
	pass # Replace with function body.
