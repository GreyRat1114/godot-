extends CanvasLayer

var PlayerHeath =45
func _ready():
	PlayerHeath=45
	refresh_player_health()
	
func refresh_player_health():
	if PlayerHeath==0:
		$AnimationPlayer.play("0")
	if PlayerHeath==5:
		$AnimationPlayer.play("1")	
	if PlayerHeath==10:
		$AnimationPlayer.play("2")	
	if PlayerHeath==15:
		$AnimationPlayer.play("3")	
	if PlayerHeath==20:
		$AnimationPlayer.play("4")	
	if PlayerHeath==25:
		$AnimationPlayer.play("5")	
	if PlayerHeath==30:
		$AnimationPlayer.play("6")	
	if PlayerHeath==35:
		$AnimationPlayer.play("7")	
	if PlayerHeath==40:
		$AnimationPlayer.play("8")	
	if PlayerHeath==45:
		$AnimationPlayer.play("9")	
	if PlayerHeath<0:
		PlayerHeath=0
		$AnimationPlayer.play("0")	
	if PlayerHeath>45:
		PlayerHeath=0
		$AnimationPlayer.play("9")		
	
	
